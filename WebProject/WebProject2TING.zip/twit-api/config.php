<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'bPG9maX3irsTn7EJ9SxcWUQW1');
    define('CONSUMER_SECRET', 'XzWPoMjLfv995FkdLhpH2npMmZDlkMxp92GzCRB5Y1OvO6xsH2');

    // User Access Token
    define('ACCESS_TOKEN', '2417559116-txT2SpEPLKQb63phGOdzA0t5guUboY87gs8UCwp');
    define('ACCESS_SECRET', 'PJgwIjL0P3p1Mospzcq0gr7xYVTawSKk35npDJXMrvpoz');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));