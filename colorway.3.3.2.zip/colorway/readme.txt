To Install Colorway Theme, Put the "colorwaytheme" directory in your wp-content/themes directory and Activate the Theme from Wordpress Admin Panel.

The Theme installs with the basic layout in place. You can configure the Home Page using the Themes Options Panel.

If you want to build a blog, use the Template Type as "Blog Page" from the Page Attributes Section within the Add new Page section. The blog would come up in the page you created.

The process is similar for creating the Contact us page and the gallery page. In the gallery page you need to upload the images using the upload image buttons and just have to save the changes. Nothing is needed to be appeared in the page as you hit publish, a nice gallery would come up. 

If you have any questions that are beyond the scope of this help file, You can Mail Us at enquiry@inkthemes.com

Theme Image Link are:-

http://pixabay.com/en/home-office-laptop-notebook-office-381229/--Slider
http://pixabay.com/en/macbook-notebook-home-office-336704/
http://pixabay.com/en/office-meeting-business-partners-336368/
http://pixabay.com/en/home-office-workstation-office-336373/
http://pixabay.com/en/coffee-cup-counter-bell-drink-423198/

License info for all js:

* MIT License for jquery.tipsy.js
* MIT and GPL licenses for superfish.js