<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
    <head>
        <title><?php print($title); ?></title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>

	<h1><?php print($title);?></h1>
	<h2>Argumenten</h2> 
	<ul><?php	
		foreach ($arguments as $a){
			print('<li>'.$a.'</li>');
		}
	?>
	</ul>
	<pre>controller = Example1.php</pre>	
	<pre>view = example1_view.php</pre>	
    </body>
</html>

