<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Example1 extends CI_Controller {

	public function args(){
		$args=func_get_args();
		$data=array("title"=> "Class Example1, method args", 
				"arguments"=> $args);
		$this->load->view('example1_view', $data);
	}
}
