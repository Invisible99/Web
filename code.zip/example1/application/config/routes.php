<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$route['default_controller'] = 'welcome';
$route['404_override'] = '';
$route['translate_uri_dashes'] = FALSE;

/*
$route['ex1'] = 'example1/args';
$route['ex1/(:any)'] = 'example1/args/$1';
$route['ex1/(:any)/(:any)'] = 'example1/args/$1/$2';
$route['ex1/(:any)/(:any)/(:any)'] = 'example1/args/$1/$2/$3';
*/
