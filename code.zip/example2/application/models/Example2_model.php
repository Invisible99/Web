<?php
class Example2_model extends CI_Model {

	function getAll($table){
		$query=$this->db->get($table);
		return $query->result();
	}
}
?>
