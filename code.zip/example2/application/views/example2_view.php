<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html>
    <head>
        <title>example2</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
	<table>
	        <?php foreach ($results as $r):?>
			<tr>
				<td> <?=$r->id?></td>
				<td> <?=$r->priority?></td>
				<td> <?=$r->text?></td>
			</tr>
		<?php endforeach;?>	
	</table>
	<pre>controller = Example2.php</pre>	
	<pre>model = Example2_model.php</pre>	
	<pre>view = example2_view.php</pre>	
    </body>
</html>

